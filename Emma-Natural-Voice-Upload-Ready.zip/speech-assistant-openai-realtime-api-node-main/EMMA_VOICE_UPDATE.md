# Emma natural voice update

This build preserves Emma's existing receptionist, customer, cleaner, applicant, pricing, booking, and tool rules while improving conversational delivery.

## Changes

- Reworked the opening system-prompt instructions around short conversational beats.
- Most turns are limited to one or two short sentences and roughly 35 spoken words.
- Emma answers first, asks at most one necessary follow-up, and then stops.
- Added stronger anti-repetition and no-double-confirmation rules.
- Added calm, slightly slower, moderately expressive voice direction.
- Changed turn detection from fixed silence timing to semantic VAD with low eagerness.
- Enabled Realtime API response interruption with `interrupt_response: true`.
- Preserved the existing Twilio `clear` event so buffered audio stops when a caller interrupts.

## Test after deployment

1. Ask a simple pricing question. Emma should answer briefly, then ask at most one question.
2. Pause mid-sentence for one second. Emma should continue listening.
3. Interrupt Emma while she is speaking. Her audio should stop promptly.
4. Say yes to an exact date/time proposal. Emma should proceed without asking for the same confirmation again.
5. Ask a cleaner question. Emma should not switch into customer sales language.
